
from pydantic_settings import BaseSettings
from pydantic import Field
class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql://postgres:SterkWachtwoord123@postgres:5432/promati"
    MINIO_ENDPOINT: str = "http://minio:9000"
    MINIO_ACCESS_KEY: str = "admin"
    MINIO_SECRET_KEY: str = "SuperSterkMinio123"
    MINIO_BUCKET: str = "files"
    MINIO_SECURE: bool = False
    QDRANT_URL: str = "http://qdrant:6333"
    KEYCLOAK_JWKS_URL: str = "http://keycloak:8080/realms/promati/protocol/openid-connect/certs"
    KEYCLOAK_ISSUER: str = "http://keycloak:8080/realms/promati"
    KEYCLOAK_AUDIENCE: str = "api"
settings = Settings()
