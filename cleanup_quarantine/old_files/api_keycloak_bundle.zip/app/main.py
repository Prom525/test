
from fastapi import FastAPI
from .routers import health, machines, inspecties
from .keycloak import verify_token

app = FastAPI(title="Promati API with Keycloak")

# Protected routers
app.include_router(machines.router, dependencies=[Depends(verify_token)])
app.include_router(inspecties.router, dependencies=[Depends(verify_token)])
# Public
app.include_router(health.router)
