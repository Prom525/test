
#!/bin/sh
set -euo pipefail

KC_BASE=${KC_BASE:-http://keycloak:8080}
REALM_NAME=${REALM_NAME:-promati}
ADMIN=${KEYCLOAK_ADMIN:-admin}
ADMIN_PW=${KEYCLOAK_ADMIN_PASSWORD:-admin123}
INIT_USERNAME=${INIT_USERNAME:-john}
INIT_PASSWORD=${INIT_PASSWORD:-Prom#t!1234}
INIT_EMAIL=${INIT_EMAIL:-john@example.com}

log(){ echo "[init-keycloak] $1"; }

# 1) Wacht tot Keycloak ready is
until curl -sf "$KC_BASE/realms/master/.well-known/openid-configuration" >/dev/null; do
  log "Wachten op Keycloak..."
  sleep 3
done
log "Keycloak bereikbaar: $KC_BASE"

# 2) Haal admin token op
ADMIN_TOKEN=$(curl -s -X POST "$KC_BASE/realms/master/protocol/openid-connect/token"   -H 'Content-Type: application/x-www-form-urlencoded'   --data "client_id=admin-cli&grant_type=password&username=${ADMIN}&password=${ADMIN_PW}" |   sed -n 's/.*"access_token":"\([^"]*\)".*//p')

if [ -z "$ADMIN_TOKEN" ]; then
  log "Kon geen admin token verkrijgen; check KEYCLOAK_ADMIN(_PASSWORD)"
  exit 1
fi

AUTH="Authorization: Bearer $ADMIN_TOKEN"
HDR="Content-Type: application/json"

# Helpers
realm_exists(){ curl -sf -H "$AUTH" "$KC_BASE/admin/realms/$REALM_NAME" >/dev/null; }

# 3) Realm aanmaken indien nodig
if realm_exists; then
  log "Realm $REALM_NAME bestaat al"
else
  log "Maak realm $REALM_NAME"
  curl -sf -X POST -H "$AUTH" -H "$HDR" "$KC_BASE/admin/realms" -d '{
    "realm":"'"$REALM_NAME"'",
    "enabled":true
  }' >/dev/null
fi

# 4) Client `api` aanmaken of bijwerken
CLIENT_ID=api
CLIENT_LOOKUP=$(curl -s -H "$AUTH" "$KC_BASE/admin/realms/$REALM_NAME/clients?clientId=$CLIENT_ID")
if echo "$CLIENT_LOOKUP" | grep -q '"id"'; then
  CID=$(echo "$CLIENT_LOOKUP" | sed -n 's/.*"id":"\([^"]*\)".*//p' | head -n1)
  log "Client $CLIENT_ID bestaat (id=$CID), updaten"
  curl -sf -X PUT -H "$AUTH" -H "$HDR" "$KC_BASE/admin/realms/$REALM_NAME/clients/$CID" -d '{
    "clientId":"api",
    "publicClient":true,
    "standardFlowEnabled":true,
    "directAccessGrantsEnabled":true,
    "redirectUris":["*"],
    "webOrigins":["*"]
  }' >/dev/null
else
  log "Maak client $CLIENT_ID"
  curl -sf -X POST -H "$AUTH" -H "$HDR" "$KC_BASE/admin/realms/$REALM_NAME/clients" -d '{
    "clientId":"api",
    "publicClient":true,
    "standardFlowEnabled":true,
    "directAccessGrantsEnabled":true,
    "redirectUris":["*"],
    "webOrigins":["*"]
  }' >/dev/null
fi

# 5) User `john` aanmaken of bijwerken
USR_LOOKUP=$(curl -s -H "$AUTH" "$KC_BASE/admin/realms/$REALM_NAME/users?username=$INIT_USERNAME")
if echo "$USR_LOOKUP" | grep -q '"id"'; then
  UID=$(echo "$USR_LOOKUP" | sed -n 's/.*"id":"\([^"]*\)".*//p' | head -n1)
  log "User $INIT_USERNAME bestaat (id=$UID), updaten"
  curl -sf -X PUT -H "$AUTH" -H "$HDR" "$KC_BASE/admin/realms/$REALM_NAME/users/$UID" -d '{
    "email":"'"$INIT_EMAIL"'",
    "emailVerified":true,
    "enabled":true,
    "requiredActions":[]
  }' >/dev/null
else
  log "Maak user $INIT_USERNAME"
  curl -sf -X POST -H "$AUTH" -H "$HDR" "$KC_BASE/admin/realms/$REALM_NAME/users" -d '{
    "username":"'"$INIT_USERNAME"'",
    "email":"'"$INIT_EMAIL"'",
    "emailVerified":true,
    "enabled":true,
    "requiredActions":[]
  }' >/dev/null
  # opnieuw lookup om UID te krijgen
  USR_LOOKUP=$(curl -s -H "$AUTH" "$KC_BASE/admin/realms/$REALM_NAME/users?username=$INIT_USERNAME")
  UID=$(echo "$USR_LOOKUP" | sed -n 's/.*"id":"\([^"]*\)".*//p' | head -n1)
fi

# 6) Wachtwoord zetten (non-temporary)
log "Stel wachtwoord in voor $INIT_USERNAME"
curl -sf -X PUT -H "$AUTH" -H "$HDR" "$KC_BASE/admin/realms/$REALM_NAME/users/$UID/reset-password" -d '{
  "type":"password",
  "temporary":false,
  "value":"'"$INIT_PASSWORD"'"
}' >/dev/null

log "Keycloak init voltooid"
